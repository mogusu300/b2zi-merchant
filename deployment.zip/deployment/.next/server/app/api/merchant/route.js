var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/merchant/route.js")
R.c("server/chunks/[root-of-the-server]__b1ded926._.js")
R.c("server/chunks/[root-of-the-server]__0015c0ff._.js")
R.c("server/chunks/_next-internal_server_app_api_merchant_route_actions_cf1e9841.js")
R.m(44545)
module.exports=R.m(44545).exports
