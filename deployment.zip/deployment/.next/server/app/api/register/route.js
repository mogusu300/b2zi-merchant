var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/register/route.js")
R.c("server/chunks/[root-of-the-server]__7e68dcaa._.js")
R.c("server/chunks/[root-of-the-server]__0015c0ff._.js")
R.c("server/chunks/_next-internal_server_app_api_register_route_actions_688c24b5.js")
R.m(20934)
module.exports=R.m(20934).exports
