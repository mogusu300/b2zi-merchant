var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/upload/route.js")
R.c("server/chunks/[root-of-the-server]__249cfdeb._.js")
R.c("server/chunks/[root-of-the-server]__0015c0ff._.js")
R.c("server/chunks/_next-internal_server_app_api_upload_route_actions_f15ed185.js")
R.m(68548)
module.exports=R.m(68548).exports
