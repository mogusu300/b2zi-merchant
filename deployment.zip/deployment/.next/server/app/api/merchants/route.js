var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/merchants/route.js")
R.c("server/chunks/[root-of-the-server]__f8181052._.js")
R.c("server/chunks/[root-of-the-server]__0015c0ff._.js")
R.c("server/chunks/_next-internal_server_app_api_merchants_route_actions_d8165de4.js")
R.m(65988)
module.exports=R.m(65988).exports
