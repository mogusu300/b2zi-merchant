globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/577bbd5eac483c13.js",
    "static/chunks/cc9e3f2a630d5cd7.js",
    "static/chunks/7af99b4fe779898e.js",
    "static/chunks/806ee517560a1092.js",
    "static/chunks/turbopack-0a577097d414bc97.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];