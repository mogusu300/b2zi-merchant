(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_73ae2169._.js",
  "static/chunks/node_modules__pnpm_fa90e3b6._.js"
],
    source: "dynamic"
});
